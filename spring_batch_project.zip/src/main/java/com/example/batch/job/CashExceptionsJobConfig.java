package com.example.batch.job;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.example.batch.tasklet.*;

@Configuration
public class CashExceptionsJobConfig {

    @Autowired
    private JobBuilderFactory jobBuilderFactory;

    @Autowired
    private StepBuilderFactory stepBuilderFactory;

    @Autowired
    private LoadReferenceDataTasklet loadReferenceDataTasklet;

    @Autowired
    private ProcessCashExceptionsTasklet processCashExceptionsTasklet;

    @Autowired
    private LoadRS2InvalidDataTasklet loadRS2InvalidDataTasklet;

    @Autowired
    private CreateExceptionEntriesTasklet createExceptionEntriesTasklet;

    @Bean
    public Job cashExceptionsProcessJob(Step loadReferenceDataStep, Step processCashExceptionsStep, Step loadRS2InvalidDataStep, Step createExceptionEntriesStep) {
        return jobBuilderFactory.get("cashExceptionsProcessJob")
                .start(loadReferenceDataStep)
                .next(processCashExceptionsStep)
                .next(loadRS2InvalidDataStep)
                .next(createExceptionEntriesStep)
                .build();
    }

    @Bean
    public Step loadReferenceDataStep() {
        return stepBuilderFactory.get("loadReferenceDataStep")
                .tasklet(loadReferenceDataTasklet)
                .build();
    }

    @Bean
    public Step processCashExceptionsStep() {
        return stepBuilderFactory.get("processCashExceptionsStep")
                .tasklet(processCashExceptionsTasklet)
                .build();
    }

    @Bean
    public Step loadRS2InvalidDataStep() {
        return stepBuilderFactory.get("loadRS2InvalidDataStep")
                .tasklet(loadRS2InvalidDataTasklet)
                .build();
    }

    @Bean
    public Step createExceptionEntriesStep() {
        return stepBuilderFactory.get("createExceptionEntriesStep")
                .tasklet(createExceptionEntriesTasklet)
                .build();
    }
}
